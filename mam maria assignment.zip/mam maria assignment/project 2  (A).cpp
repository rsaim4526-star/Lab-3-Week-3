// Sheraz Ahmed
// L1F26BSCS0097
 
#include <iostream>
using namespace std; // Error 1: Namespace was missing

int main()
{
    // Error 2: Semicolon was missing
    cout << "Orientation Day" << endl;

    // Error 3: << was missing before 450
    cout << "Total students: " << 450 << endl;

    // Print remaining seats
    cout << "Seats left: " << 500 - 450 << endl;

    // Error 4: Closing double quote was missing
    cout << "Have a nice day" << endl;

    return 0;
}